function ExecuteScript(strId)
{
  switch (strId)
  {
      case "5qUzBZ30HWn":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

